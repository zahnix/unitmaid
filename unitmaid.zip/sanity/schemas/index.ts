import blogs from './blogs'
export const schemaTypes = [blogs]